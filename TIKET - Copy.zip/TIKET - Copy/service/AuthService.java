package NathanPBO2.TIKET.service;

import org.springframework.stereotype.Service;

import NathanPBO2.TIKET.model.User;
import NathanPBO2.TIKET.repository.UserRepository;

@Service
public class AuthService {
    private final UserRepository userRepository;

    public AuthService (UserRepository userRepository) {
        this.userRepository = userRepository;

    }

    public User login(String username, String Password) {
        return userRepository.findByUsernameAndPassword(username, Password);
    }
    
}
