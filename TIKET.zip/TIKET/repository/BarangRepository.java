package NathanPBO2.TIKET.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import NathanPBO2.TIKET.model.Barang;

@Repository
public interface BarangRepository extends JpaRepository<Barang, String> {

}